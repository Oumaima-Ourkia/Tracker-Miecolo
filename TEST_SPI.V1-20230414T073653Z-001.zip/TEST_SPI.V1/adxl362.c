/*******************************************************************************

adxl362.c regroupe tous les fonctions necessaires a l'utilisation de 
l'accéléromtre adxl362

******************************************************************************/

#include <stdio.h>
#include <math.h>
#include "em_cmu.h"
#include "em_gpio.h"
#include "em_usart.h"
#include "adxl362.h"
#include "sl_udelay.h"
#include "em_device.h"
#include "em_chip.h"


/**************************************************************************//**
* GPIO initialisation des pins pour la communication SPI avec l'adxl362
*****************************************************************************/
void adxl362_initGpio(void)
{
	// Configure RX pin as an input
	GPIO_PinModeSet(US0MISO_PORT, US0MISO_PIN, gpioModeInput, 0);

	// Configure TX pin as an output
	GPIO_PinModeSet(US0MOSI_PORT, US0MOSI_PIN, gpioModePushPull, 0);

	// Configure CLK pin as an output low (CPOL = 0)
	GPIO_PinModeSet(US0CLK_PORT, US0CLK_PIN, gpioModePushPull, 0);

	// Configure CS pin as an output and drive inactive high
	GPIO_PinModeSet(US0CS_PORT, US0CS_PIN, gpioModePushPull, 1);
}

/**************************************************************************//**
*    USART1 initialisation en mode SPI
*****************************************************************************/
void adxl362_initUSART1(void)
{
#define SL_ADXL362_SPI_PERIPHERAL               USART1
  USART_TypeDef *usart = SL_ADXL362_SPI_PERIPHERAL;

	// Default asynchronous initializer (master mode, 1 Mbps, 8-bit data)
	USART_InitSync_TypeDef init = USART_INITSYNC_DEFAULT;

	// Enable clock (not needed on xG21)
	CMU_ClockEnable(cmuClock_USART1, true);
	init.msbf = true;   // MSB first transmission for SPI compatibility
	init.baudrate = 2000000;	// vitesse de transmission des données doit etre compris entre 1 et 8 MHz

	/*
	* Route USART1 RX, TX, and CLK to the specified pins.  Note that CS is
	* not controlled by USART1 so there is no write to the corresponding
	* USARTROUTE register to do this.
	*/
	GPIO->USARTROUTE[0].RXROUTE = (US0MISO_PORT << _GPIO_USART_RXROUTE_PORT_SHIFT)
	| (US0MISO_PIN << _GPIO_USART_RXROUTE_PIN_SHIFT);
	GPIO->USARTROUTE[0].TXROUTE = (US0MOSI_PORT << _GPIO_USART_TXROUTE_PORT_SHIFT)
	| (US0MOSI_PIN << _GPIO_USART_TXROUTE_PIN_SHIFT);
	GPIO->USARTROUTE[0].CLKROUTE = (US0CLK_PORT << _GPIO_USART_CLKROUTE_PORT_SHIFT)
	| (US0CLK_PIN << _GPIO_USART_CLKROUTE_PIN_SHIFT);

	// Enable USART interface pins
	GPIO->USARTROUTE[0].ROUTEEN = GPIO_USART_ROUTEEN_RXPEN |    // MISO
	GPIO_USART_ROUTEEN_TXPEN |    // MOSI
	GPIO_USART_ROUTEEN_CLKPEN;

	// Configure and enable USART1
	USART_InitSync(usart, &init);
}


/***************************************************************************//**
* Initialisation de la communication SPI avec l'adxl362
******************************************************************************/
void adxl362_spi_init(void)
{
  adxl362_initUSART1();
	adxl362_initGpio();
}

/***************************************************************************//**
* Lecture d'un registre de l'adxl362
* Parametre : addr = adresse du registre 
******************************************************************************/
uint8_t adxl362_read_register(uint8_t addr)
{
	uint8_t RegValue = 0;

	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);		  // indique a l'adxl362 le debut d'une communication SPI

	USART_SpiTransfer(USART1, 0x0B);				      // commande de lecture de registre
	USART_SpiTransfer(USART1, addr);				      // adresse du registre a lire
	RegValue = USART_SpiTransfer(USART1, 0x00);		// lecture du registre

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);			  // ferme la communication avec l'adxl362
	sl_udelay_wait(120);							            // delay permettant au registre STATUS de se mettre a jour

	return RegValue;
}

/***************************************************************************//**
* Lecture de 2 registres succesif de l'adxl362 
* Parametre : addr = adresse du registre de poids faible 
******************************************************************************/
uint16_t adxl362_read_two_register(uint8_t addr)
{
	uint16_t twoRegValue = 0;

	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

	USART_SpiTransfer(USART1, 0x0B);
	USART_SpiTransfer(USART1, addr);
	twoRegValue = USART_SpiTransfer(USART1, 0x00);						          // lecture du 1er registre (poid faible)
	twoRegValue = twoRegValue + (USART_SpiTransfer(USART1, 0x00) << 8); // lecture du 2ème registre (poid fort) et mise en forme

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
	sl_udelay_wait(120);

	return twoRegValue;
}  

/***************************************************************************//**
* Ecriture d'un registre de l'adxl362 
* Parametres	: addr = adresse du registre 
*				: data = donnée a écrire
******************************************************************************/
void adxl362_write_register(uint8_t addr, uint8_t data)
{
	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

	USART_SpiTransfer(USART1, 0x0A);	// commande d'écriture de registre
	USART_SpiTransfer(USART1, addr);	// adresse du registre ou écrire
	USART_SpiTransfer(USART1, data);	// donnée a écrire
	
	                                  // ici pas de delay nécessaire uniquement en lecture

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
}

/***************************************************************************//**
* Ecriture de 2 registres succesif de l'adxl362 
* Parametres	: addr = adresse du registre de poids faible 
*				: data = donnée a écrire
******************************************************************************/
void adxl362_write_two_register(uint8_t addr, uint16_t data)
{
	uint8_t dataH = data >> 8;	// découpage de la donnée en 2 (ici poids fort)
	uint8_t dataL = data;		    // découpage de la donnée en 2 (ici poids faible)

	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

	USART_SpiTransfer(USART1, 0x0A);
	USART_SpiTransfer(USART1, addr);
	USART_SpiTransfer(USART1, dataL);	// poids faible écrit en 1er
	USART_SpiTransfer(USART1, dataH);	// poids  fort écrit en 2ème

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
}

/***************************************************************************//**
* Lecture des données X,Y et Z sur 8bits avec la fonction adxl362_read_register
******************************************************************************/
int8_t adxl362_readXData8bits(void)
{
	int8_t XData;
	XData = (int8_t)adxl362_read_register(ADXL362_XDATA);
	return XData;
}

int8_t adxl362_readYData8bits(void)
{
	int8_t YData;
	YData = (int8_t)adxl362_read_register(ADXL362_YDATA);
	return YData;
}

int8_t adxl362_readZData8bits(void)
{
	int8_t ZData;
	ZData = (int8_t)adxl362_read_register(ADXL362_ZDATA);
	return ZData;
}

/***************************************************************************//**
* Lecture des données X,Y,Z et Temperature (Temp) 
* sur 12bits avec la fonction adxl362_read_two_register
******************************************************************************/
int16_t adxl362_readXData12bits(void)
{
	int16_t XData;
	XData = (int16_t)adxl362_read_two_register(ADXL362_XDATA_L);
	return XData;
}

int16_t adxl362_readYData12bits(void)
{
	int16_t YData;
	YData = (int16_t)adxl362_read_two_register(ADXL362_YDATA_L);
	return YData;
}

int16_t adxl362_readZData12bits(void)
{
	int16_t ZData;
	ZData = (int16_t)adxl362_read_two_register(ADXL362_ZDATA_L);
	return ZData;
}

int16_t adxl362_readTempData12bits(void)
{
	int16_t Temp;
	Temp = (int16_t)adxl362_read_two_register(ADXL362_TEMP_L);
	return Temp;
}

/***************************************************************************//**
* Lecture du nombres d'échantillons présent dans la FIFO
******************************************************************************/
uint16_t adxl362_fifo_nb_sample(void)
{
	uint16_t nb_samples = adxl362_read_two_register(ADXL362_FIFO_ENTRIES_L);
	return nb_samples;
}

/***************************************************************************//**
* Lecture des données X,Y et Z en une seul fonction 
* permet de gagner en rapidite car la communication est ouverte une seul fois
* Parametres	: XData, YData, ZData = adresses des variables
******************************************************************************/
void adxl362_readXYZData(int16_t *XData, int16_t *YData, int16_t *ZData)
{	  
	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

	adxl362_spi_init();
	USART_SpiTransfer(USART1, 0x0B);
	USART_SpiTransfer(USART1, ADXL362_XDATA);

	*XData = USART_SpiTransfer(USART1, 0x00);
	*XData = *XData + (USART_SpiTransfer(USART1, 0x00) << 8);

	*YData = USART_SpiTransfer(USART1, 0x00);
	*YData = *YData + (USART_SpiTransfer(USART1, 0x00) << 8);

	*ZData = USART_SpiTransfer(USART1, 0x00);
	*ZData = *ZData + (USART_SpiTransfer(USART1, 0x00) << 8);

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
	sl_udelay_wait(120);
}



/***************************************************************************//**
* Reset de l'adxl362
******************************************************************************/
void adxl362_reset(void)
{
	// 0x52 correspond a R en ascii c'est le code pour reset l'adxl362
	adxl362_write_register(ADXL362_SOFT_RESET,0x52);

	sl_udelay_wait(1000);	// tempo du temps de reset de l'adxl362
}


/***************************************************************************//**
* Lecture du registre STATUS de l'adxl362 permet de connaitre l'etat 
* dans le quel ce trouve l'adxl362.
* Permet également de clear des interruptions
******************************************************************************/	
uint8_t adxl362_status(void)
{
	uint8_t status = adxl362_read_register(ADXL362_STATUS);

	sl_udelay_wait(1000);	// temps de mise a jour du STATUS
	return status;
}

/***************************************************************************//**
* Ecriture des parametres de detections dans les registres.
* Parametres choisi au préalable en modifiant detection 
* Parametre	: detection = variable des parametres souhaité pour la detection
******************************************************************************/
void adxl362_detection_config(adxl362_detection_TypeDef *detection)
{
	uint8_t detection_control;

	// mise en forme des parametres pour le registre ADXL362_ACT_INACT_CTL
	detection_control = (detection->mode << 4) + (detection->inactRef << 3) +	\
		(detection->inactEn << 2) + (detection->actRef << 1) + (detection->actEn);

	// ecriture des parametres dans les registres
	adxl362_write_two_register(ADXL362_THRESH_ACT_L, detection->threshAct);
	adxl362_write_register(ADXL362_TIME_ACT, detection->timeAct);
	adxl362_write_two_register(ADXL362_THRESH_INACT_L, detection->threshInact);
	adxl362_write_two_register(ADXL362_TIME_INACT_L, detection->timeInact);
	adxl362_write_register(ADXL362_ACT_INACT_CTL, detection_control);
}

/***************************************************************************//**
* Ecriture des parametres de la FIFO dans les registres.
* Parametres choisi au préalable en modifiant fifo 
* Parametre	: fifo = variable des parametres souhaité pour la FIFO
******************************************************************************/
void adxl362_fifo_config(adxl362_fifo_TypeDef *fifo)
{
	uint8_t fifo_control = 0;
	uint16_t fifo_samples = fifo->sample;

	// vérification si le seuil d'echantillons est supérieur a 255 (car registre sur 8bits)
	if (fifo_samples >= 512/2){					        // si oui
		fifo_control = (1<<3);						        // mise a du bit 3 de ADXL362_FIFO_CONTROL (qui joue le role de 9ème bit)
		fifo_samples = (fifo_samples - (512/2));	// soustraction de 256 au nombre d'échantillons initial
	}

	// mise en forme des parametres pour le registre ADXL362_FIFO_CONTROL
	fifo_control = fifo_control + (fifo->temp << 2) + fifo->mode;	

	// ecriture des parametres dans les registres
	adxl362_write_register(ADXL362_FIFO_CONTROL, fifo_control);
	fifo_samples = (uint8_t)fifo_samples;
	adxl362_write_register(ADXL362_FIFO_SAMPLES, fifo_samples);
}

/***************************************************************************//**
* Ecriture des parametres des interruptions dans les registres.
* Parametres choisi au préalable en modifiant interruption 
* Parametres	: interruption = variable des parametres souhaité pour l'interruption
*				: numInt = choix de l'interruption (1 ou 2)
******************************************************************************/
void adxl362_interruption_config(adxl362_interruption_TypeDef *interruption, int numInt)
{
	uint8_t interruption_config;

	// mise en forme des parametres pour le registre de l'interruption choisi
	interruption_config = (interruption->intLow << 7) + (interruption->awake << 6)                	\
	+ (interruption->inact << 5) + (interruption->act << 4) + (interruption->fifoOverRun << 3)  	\
	+ (interruption->fifoWaterMark << 2) + (interruption->fifoReady << 1) + (interruption->dataReady);

	// choix de l'interruption a utilisé 
	if (numInt == 1)
		adxl362_write_register(ADXL362_INTMAP1, interruption_config);
	else if (numInt == 2)
		adxl362_write_register(ADXL362_INTMAP2, interruption_config);
	else
		printf("\nNumero de l'interruption n'est pas correcte soit 1 ou 2\n");
}

/***************************************************************************//**
* Ecriture des parametres de filter dans les registres.
* Parametres choisi au préalable en modifiant filtre 
* Parametre	: filtre = variable des parametres souhaité pour filter
******************************************************************************/
void adxl362_filtre_config(adxl362_filtre_TypeDef *filtre)
{
	uint8_t filtre_control;

	// mise en forme des parametres pour le registre ADXL362_FILTER_CTL
	filtre_control = (filtre->range << 6) + (filtre->halfBw << 4)                \
						+ (filtre->extSample << 3) + (filtre->odr);

	// ecriture des parametres dans le registre
	adxl362_write_register(ADXL362_FILTER_CTL, filtre_control);
}

/***************************************************************************//**
* Ecriture des parametres de power dans les registres.
* Parametres choisi au préalable en modifiant power 
* Parametre	: power = variable des parametres souhaité pour power
******************************************************************************/
void adxl362_power_config(adxl362_power_TypeDef *power)
{
	uint8_t power_control;

	// mise en forme des parametres pour le registre ADXL362_POWER_CTL
	power_control = (power->extClk << 6) + (power->lowNoiseMode << 4)                \
					+ (power->wakeUp << 3) + (power->autoSleep << 2) + (power->measureMode) ;

	// ecriture des parametres dans le registre
	adxl362_write_register(ADXL362_POWER_CTL, power_control);
}

/***************************************************************************//**
* Initialisation de l'adxl362 en modifiant les differentes variables 
* qui vont servir ensuite au fonctions de configuration
* Attention ne pas modifier l'ordre de configuration des registres
******************************************************************************/
void adxl362_init(void)
{
	////////////////////////////////////////////////////////////////////
	// Déclarations des varibles que l'on va pouvoir venir modifié au besoin
	// et qui font servir par la suite au fonction de configuration.
	// Elles sont déclarées avec les valeurs par défauts donc ne modifiront
	// pas le comportement initial de l'adxl362 si aucun modification 
	// n'est apportée par la suite
	////////////////////////////////////////////////////////////////////
	adxl362_detection_TypeDef detection = ADXL362_DETECTION_DEFAULT;
	adxl362_fifo_TypeDef fifo = ADXL362_FIFO_DEFAULT;
	adxl362_interruption_TypeDef interruption = ADXL362_INTERRUPTION_DEFAULT;
	adxl362_filtre_TypeDef filtre = ADXL362_FILTRE_DEFAULT;
	adxl362_power_TypeDef power = ADXL362_POWER_DEFAULT;


	//adxl362_reset();

	/**************************  DETECTION  *************************************/

	// modification de la variable detection
	detection.actEn = 1;
	detection.actRef = 1;
	detection.threshAct = 180;
	detection.timeAct = 25;
	detection.inactEn = 1;
	detection.inactRef = 1;
	detection.threshInact = 180;
	detection.timeInact = 25;
	detection.mode = detectionLinked;

	// configuration de la detection
	adxl362_detection_config(&detection);

	/*******************************  FIFO  *************************************/

	// modification de la variable fifi


	// configuration de la FIFO
	adxl362_fifo_config(&fifo);

	/*************************  INTERRUPTION ************************************/
	// modification de la variable interruption
	interruption.awake = 1;

	// configuration de l'interruption
	adxl362_interruption_config(&interruption, 1);

	/*****************************  FILTRE  *************************************/
	// modification de la variable filtre
	filtre.odr = odr_12_5Hz;

	// configuration du filtre
	adxl362_filtre_config(&filtre);

	/******************************  POWER  *************************************/
	// modification de la variable power
	power.wakeUp = 1;
	power.autoSleep = 1;
	power.measureMode = measure;

	// configuration de power
	adxl362_power_config(&power);

	////////////////////////////////////////////////////////////////////
	// affichage des registres pour verifier que les configurations 
	// on été effectuer. A retirer par la suite
	////////////////////////////////////////////////////////////////////
	adxl362_checkAllControlRegs();
}


/*********************************************************************
* Fonction d'analyse de mouvement qui va utiliser pour verifier
* si le mouvement est un mouvement continu (susceptible  d'être un vol)
* ou non. Les seuils seront a ajuster par la suite lors des phases de test
* Parametres	: port = port du pin de reveil du mode EM4
*				: pin = pin de reveil du mode EM4
*********************************************************************/
uint8_t adxl362_analyseMouvement(GPIO_Port_TypeDef port, unsigned int pin)
{
	int16_t XDataM, YDataM, ZDataM;
	int16_t XDataP, YDataP, ZDataP;
  ////////////////////////////////////////////////////////////////////
	// les variables limite sont les seuils que seront a ajuster par la suite
	// attention limiteTemps 1 = 160ms sauf si modification des delay (a la fin de la boucle while)
  ////////////////////////////////////////////////////////////////////
	uint8_t limiteTemps = 50;
	uint8_t limiteMvt = 50;
	uint8_t limiteAcc = 30; // valeur mini constater 30mg

	// variables qui vont s'incrémenter et qui seront comparer au seuil fixer par les limites
	uint8_t temps = 0;
	uint8_t mvt = 0;

	// variable qui sera retourne. Si aucun vol detecter = 0
	uint8_t resultat = 0; 


	// Initialisation des mesures précedentes
	adxl362_readXYZData(&XDataP, &YDataP, &ZDataP);
	printf("\nP init   : x = %d, y = %d, z = %d\n", XDataP, YDataP, ZDataP);

	// l'appel a la fonction status permet de traiter l'interruption
	printf("status interruption : %x\n", adxl362_status());

	////////////////////////////////////////////////////////////////////
	// La boucle va durée le temps que l'interruption soit active 
	// ou jusqu'à se qu'une limite soit atteinte
	////////////////////////////////////////////////////////////////////
	while(GPIO_PinInGet(port, pin) && temps < limiteTemps && mvt < limiteMvt)
	{
		// recuperation des accelerations
	  adxl362_readXYZData(&XDataM, &YDataM, &ZDataM);
		printf("Mesure : x = %d, y = %d, z = %d\n", XDataM, YDataM, ZDataM);

		////////////////////////////////////////////////////////////////////
		// Comparaison des accélérations actuelle avec les precedentes 
		// afin de voir si une difference se constate
		// si une différence est superieur a la limite on vient incrementer mvt
		////////////////////////////////////////////////////////////////////
		if (fabs(XDataP) - fabs(XDataM) >= limiteAcc)
			mvt++;
		if (fabs(YDataP) - fabs(YDataM) >= limiteAcc)
			mvt++;
		if (fabs(ZDataP) - fabs(ZDataM) >= limiteAcc)
			mvt++;

		// remplacement des valeur précedentes par les valeurs actuelles
		XDataP = XDataM;
		YDataP = YDataM;
		ZDataP = ZDataM;

		// incrémation de la variable temps
		temps++;

		// delay entre 2 mesures a modifier en fonction de la fréquence d'échantillonnage utilisé
		sl_udelay_wait(80000); 
		sl_udelay_wait(80000); 
	}

	////////////////////////////////////////////////////////////////////
	// si une des limites a été atteinte, on vient modifier resultat 
	// pour signifier qu'un vol est en cours
	////////////////////////////////////////////////////////////////////
	if (mvt >= limiteMvt || temps >= limiteTemps) {
		resultat = 1;
	}
	printf("nb mesure = %d  mouvement = %d\n", temps, mvt);

	return resultat;
}

/*********************************************************************
* Fonction qui attend la fin de l'interruption 
* Attention la fonction est faite pour une interruption 
* active a l'état haut
* Parametres	: port = port du pin de reveil du mode EM4
*				: pin = pin de reveil du mode EM4
*********************************************************************/
void adxl362_stopInterruption(GPIO_Port_TypeDef port, unsigned int pin)
{
	uint8_t i = 0;
	uint8_t delayTraitement = 60; // 1 = 100ms

	// l'appel a la fonction status permet de traiter l'interruption
	printf("status interruption : %x\n", adxl362_status()); 

	////////////////////////////////////////////////////////////////////
	// attente que l'interruption revient a l'etat bas 
	// Modifier la condition (!) si interruption est active a l'etat bas
	////////////////////////////////////////////////////////////////////
	while(GPIO_PinInGet(port, pin))   
	{
		////////////////////////////////////////////////////////////////////
		// si l'interruption est toujours active après le temps de traitement  
		// rappeler la fonction de leture du status 
		// (qui n'a peut etre pas fonctionner avant)
		////////////////////////////////////////////////////////////////////
		if(i > delayTraitement){	
			printf("status interruption : %x\n", adxl362_status());
			i = 0;
		}
		sl_udelay_wait(100000);
		i++;
	}
	printf("pin = %d", GPIO_PinInGet(port, pin)); //affiche l'etat de la pin
}

/***************************************************************************//**
* Lecture des registers de 0 a 3 afin de verifier que la lecture fonctions 
* a utiliser uniquement pour debuger
******************************************************************************/
void adxl362_checkAllID(void)
{	
	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

	USART_SpiTransfer(USART1, 0x0B);
	USART_SpiTransfer(USART1, ADXL362_DEVID_AD);

	printf("Reg 00 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 01 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 02 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 03 = %x\n",USART_SpiTransfer(USART1, 0x00));

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
}

/***************************************************************************//**
* Lecture des registers de 20 à 2E afin de verifier que la configuration
* des registres a fonctionné. A utiliser uniquement pour debuger
******************************************************************************/
void adxl362_checkAllControlRegs(void)
{	
	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

	USART_SpiTransfer(USART1, 0x0B);
	USART_SpiTransfer(USART1, ADXL362_THRESH_ACT_L);

	printf("Reg 20 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 21 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 22 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 23 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 24 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 25 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 26 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 27 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 28 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 29 = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 2A = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 2B = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 2C = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 2D = %x\n",USART_SpiTransfer(USART1, 0x00));
	printf("Reg 2E = %x\n",USART_SpiTransfer(USART1, 0x00));

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
}

/***************************************************************************//**
* ATTENTION FONCTION NON FINI NE PAS UTILISER EN L'ETAT
* Lecture des données dans la FIFO
* Lit le nombres d'échantillons entrer en parametres nb_samples
* Mets les echantillons dans le tableau tabFifo 
* Parametres	: nb_samples = nombre d'échantillons a lire
*				: tabFifo = adresse du tableau ou mettre les echantillons
******************************************************************************/
void adxl362_readFIFO(uint16_t nb_samples, uint16_t *tabFifo)
{
	GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);
	USART_SpiTransfer(USART1, 0x0D);	// commande de lecture de la FIFO
										// pas d'adresse a indique apres

	uint16_t twoRegValue;

	for(int i = 0; i < nb_samples ; i++){
		twoRegValue = USART_SpiTransfer(USART1, 0x00);
		twoRegValue = twoRegValue + (USART_SpiTransfer(USART1, 0x00) << 8);
		tabFifo[i] = twoRegValue;
	}

	GPIO_PinOutSet(US0CS_PORT, US0CS_PIN);
	sl_udelay_wait(120);
}

/***************************************************************************//**
* ATTENTION FONCTION NON FINI NE PAS UTILISER EN L'ETAT
* Fonction qui réalise l'autotest de l'adxl362
* Parametre	: mode = (true) demarre l'autotest ou (false) le stop
******************************************************************************/
void adxl362_self_test(bool mode)
{
	if (mode == true)
		adxl362_write_register(ADXL362_SELF_TEST,0x01);
	else
		adxl362_write_register(ADXL362_SELF_TEST,0x00);
}
