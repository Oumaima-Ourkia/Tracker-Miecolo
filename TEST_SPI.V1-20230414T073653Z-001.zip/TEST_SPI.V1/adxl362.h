/*******************************************************************************



******************************************************************************/

#ifndef ADXL362_H	
#define ADXL362_H

#include <stdint.h>
#include <stdbool.h>
#include "sl_status.h"
#include "em_gpio.h"


/****************/
/* Register map */
/****************/

#define ADXL362_DEVID_AD 				    0x00
#define ADXL362_DEVID_MST    				0x01
#define ADXL362_PARTID 			    		0x02
#define ADXL362_REVID 					    0x03
#define ADXL362_XDATA 				    	0x08
#define ADXL362_YDATA 					    0x09
#define ADXL362_ZDATA 					    0x0A
#define ADXL362_STATUS 					    0x0B
#define ADXL362_FIFO_ENTRIES_L 			0x0C
#define ADXL362_FIFO_ENTRIES_H 			0x0D 
#define ADXL362_XDATA_L 				    0x0E
#define ADXL362_XDATA_H 				    0x0F
#define ADXL362_YDATA_L 				    0x10
#define ADXL362_YDATA_H 				    0x11
#define ADXL362_ZDATA_L 				    0x12
#define ADXL362_ZDATA_H 				    0x13
#define ADXL362_TEMP_L 					    0x14
#define ADXL362_TEMP_H 					    0x15
#define ADXL362_Reserved 				    0x16
#define ADXL362_Reserved2 				  0x17
#define ADXL362_SOFT_RESET 				  0x1F
#define ADXL362_THRESH_ACT_L 			  0x20
#define ADXL362_THRESH_ACT_H 			  0x21
#define ADXL362_TIME_ACT 				    0x22
#define ADXL362_THRESH_INACT_L 			0x23
#define ADXL362_THRESH_INACT_H 			0x24
#define ADXL362_TIME_INACT_L 			  0x25
#define ADXL362_TIME_INACT_H 			  0x26
#define ADXL362_ACT_INACT_CTL 			0x27
#define ADXL362_FIFO_CONTROL 			  0x28
#define ADXL362_FIFO_SAMPLES 			  0x29
#define ADXL362_INTMAP1 				    0x2A
#define ADXL362_INTMAP2 				    0x2B
#define ADXL362_FILTER_CTL 				  0x2C
#define ADXL362_POWER_CTL 				  0x2D
#define ADXL362_SELF_TEST 				  0x2E


/******************************************************************************
* Configuration pin_tool
******************************************************************************/

// Ports and pins for SPI interface
#define US0MISO_PORT  gpioPortA
#define US0MISO_PIN   6
#define US0MOSI_PORT  gpioPortA
#define US0MOSI_PIN   7
#define US0CLK_PORT   gpioPortA
#define US0CLK_PIN    8
#define US0CS_PORT    gpioPortA
#define US0CS_PIN     4


/******************************************************************************

* Definition des differents type pour la configuration de l'adxl362

******************************************************************************/

//////////////////////////////////Detection///////////////////////////////////

/** Enumeration pour le parametre mode de detection*/
typedef enum {

	detectionDefaut     = 0b00,	    // la detection d'activite et d'inactivité sont indépandante, le capteur reste toujours allumé

	detectionLinked     = 0b01,	    // il y a une alternance entre activite et inactivité. Il faut clear l'interruption
									                // pour pouvoir poursuivre l'alternance sinon l'adxl362 reste en attente
	                                // faire appele a la fonction adxl362_status pour clear l'interruption

	detectionLoop       = 0b11	    // il y a une alternance entre activite et inactivité mais ici pas besoin de clear l'interruption

} adxl362_detection_mode_TypeDef;

/** Parametres de la configuration de la detection */
typedef struct {

	uint16_t                            threshAct;      // seuil a dépasser (passer au dessus du seuil) pour déclencher l'interruption
														                          // THRESH_ACT [mg] = THRESH_ACT [codes sur 11bits]/Sensitivity[codes per mg]

	uint8_t                             timeAct;        // durée durant laquelle le seuil doit être dépasser pour déclencher l'interruption
														                          // Time [s] = TIME_ACT[codes sur 8bits]/ODR [Hz]

	uint16_t                            threshInact;    // seuil a dépasser (passer sous le seuil) pour déclencher l'interruption
														                          // THRESH_INACT [mg] = THRESH_INACT [codes sur 11bits]/Sensitivity[codes per mg]

	uint16_t                            timeInact;      // durée durant laquelle le seuil doit etre dépasser pour déclencher l'interruption
														                          // Time [s] = TIME_ACT[codes sur 16bits]/ODR [Hz]
		
	adxl362_detection_mode_TypeDef      mode;           // Mode de detection voir enumération

	bool                                inactRef;       // Inactivité en mode reference (1) ou absolue (0)

	bool                                inactEn;        // Activation (1) ou non (0) de l'inactivité

	bool                                actRef;         // Activité en mode reference (1) ou absolue (0)

	bool                                actEn;          // Activation (1) ou non (0) de l'activité

} adxl362_detection_TypeDef;

/** Déclaration de detection default 
ATTENTION NE PAS MODIFIER ICI LES PARAMETRES MAIS DANS LE adxl362.c*/
#define ADXL362_DETECTION_DEFAULT   \
{                                 	\
	detectionDefaut,                  \
	0,  								              \
	0,                                \
	0,                                \
	0,                                \
	0,                                \
	0,                                \
	0,                                \
	0                                 \
}

//////////////////////////////////FIFO///////////////////////////////////

/** Enumeration pour le parametre mode de FIFO */
typedef enum {

	fifoDisable			  = 0b00,			//fifo desactiver
	fifoOldestSaved 	= 0b01,			//la fifo enregistre les elements tant que la fifo n'est pas plein puis se bloque.
	fifoStream 		    = 0b10,			//la fifo garde en mémoire les echantillons les plus récents (supprime le plus vieille echantillons quand plus de place)
	fifoTriggered     = 0b11			//la fifo n'enregistre que quand un evenement a eu lieu (activité, inactivité)

} adxl362_fifo_mode_TypeDef;

/** Parametres de la configuration de la FIFO */
typedef struct {

	adxl362_fifo_mode_TypeDef		mode;		  // Mode de fonctionnement de la fifo voir enumeration

	bool							          temp;		  // enregistre en plus la temperature si (1)

	uint16_t						        sample;		// seuil d'échantillon (pour interruption)

} adxl362_fifo_TypeDef;

/** Déclaration de FIFO default 
ATTENTION NE PAS MODIFIER ICI LES PARAMETRES MAIS DANS LE adxl362.c*/
#define ADXL362_FIFO_DEFAULT	\
{                             \
	fifoDisable,				        \
	0,							            \
	0x80						            \
}


//////////////////////////////////Interruption///////////////////////////////////

/** Parametres de la configuration d'une interruption */
typedef struct {

	bool			intLow;               //L'interruption est active (0) à l'état haut (1) à l'état bas

	bool			awake;                //Interruption quand l'appareil est allumé

	bool			inact;                //Interruption quand une inactivité est détecté

	bool			act;                  //Interruption quand une activité est détecté

	bool			fifoOverRun;          //Interruption quand la FIFO est pleine ou déborde

	bool			fifoWaterMark;        //Interruption quand la FIFO atteint le nombres de samples demander

	bool			fifoReady;            //Interruption quand au moins un samples est present dans la FIFO

	bool			dataReady;            //Interruption quand des données sont disponible à la lecture

} adxl362_interruption_TypeDef;

/** Déclaration de interruption default 
ATTENTION NE PAS MODIFIER ICI LES PARAMETRES MAIS DANS LE adxl362.c*/
#define ADXL362_INTERRUPTION_DEFAULT    \
{                                     	\
	0,                                    \
	0,                                    \
	0,                                    \
	0,                                    \
	0,                                    \
	0,                                    \
	0,                                    \
	0                                     \
}


//////////////////////////////////FILTRE///////////////////////////////////

/** Enumeration pour le parametre range de filter */
typedef enum {

	range2g		  = 0b00,
	range4g     = 0b01,
	range8g     = 0b11

} adxl362_filtre_range_TypeDef;

/** Enumeration pour le parametre odr de filter */
typedef enum {

	odr_12_5Hz   = 0b000,
	odr_25Hz     = 0b001,
	odr_50Hz     = 0b010,
	odr_100Hz    = 0b011,
	odr_200Hz    = 0b100,
	odr_400Hz    = 0b111

} adxl362_filtre_odr_TypeDef;

/** Parametres de la configuration de filter */
typedef struct {

	adxl362_filtre_range_TypeDef        range;        //Selection de la plage d'acceleration voir enumeration

	bool                                halfBw;       // (0) Redit la bande passant à 1/2 de l'ODR pour avoir une antialiasing moyen
	                                                  // (1) Reduit la bande passant à 1/4 de l'ODR pour avoir une antialiasing éleve

	bool                                extSample;    //(1) la broche INT2 est utiliser pour le controle de synchronisation de conversion externe

	adxl362_filtre_odr_TypeDef			    odr;          //Selection de la fréquence d'échantillonage voir enumeration

} adxl362_filtre_TypeDef;

/** Déclaration de filtre default 
ATTENTION NE PAS MODIFIER ICI LES PARAMETRES MAIS DANS LE adxl362.c*/
#define ADXL362_FILTRE_DEFAULT          \
{                                     	\
	range2g,                              \
	1,                                    \
	0,                                    \
	odr_100Hz                             \
}

//////////////////////////////////POWER///////////////////////////////////

/** Enumeration pour le parametre lowNoiseMode de power */
typedef enum {
	// ATTENTION reduire le bruit augmente la puissance utiliser voir la documentation pour plus de détail
	normal			    = 0b00,
	lowNoise        = 0b01,
	ultraLowNoise   = 0b10

} adxl362_power_noise_TypeDef;

/** Enumeration pour le parametre measureMode de power */
typedef enum {

	standby   = 0b00,
	measure   = 0b10,

} adxl362_power_measure_TypeDef;

/** Parametres de la configuration de power */
typedef struct {

	bool                                extClk;             // L'accéléromètre fonctionne avec une horloge externe fournit par la broche INT1

	adxl362_power_noise_TypeDef         lowNoiseMode;       // Choix du mode puissance/bruit voir enumeration

	bool                                wakeUp;             // L'accéléromètre fonctionne en mode reveille

	bool                                autoSleep;          // Utilisable uniquement si la detection est en mode LINK ou LOOP
															                            // met l'accéléromètre automatiquement en sommeil apres une inactivité
		
	adxl362_power_measure_TypeDef       measureMode;        // Activation ou mise en Standby de la mesure

} adxl362_power_TypeDef;

/** Déclaration de power default 
ATTENTION NE PAS MODIFIER ICI LES PARAMETRES MAIS DANS LE adxl362.c*/
#define ADXL362_POWER_DEFAULT           \
{                                     	\
	0,                                    \
	normal,                               \
	0,                                    \
	0,                                    \
	standby                               \
}



/***************************************************************************//**
* Initialisation de la communication SPI avec l'adxl362
******************************************************************************/
void adxl362_spi_init(void);

/***************************************************************************//**
* Lecture d'un registre de l'adxl362
* Parametre : addr = adresse du registre 
******************************************************************************/
uint8_t adxl362_read_register(uint8_t addr);

/***************************************************************************//**
* Lecture de 2 registres succesif de l'adxl362 
* Parametre : addr = adresse du registre de poids faible 
******************************************************************************/
uint16_t adxl362_read_two_register(uint8_t addr);

/***************************************************************************//**
* Ecriture d'un registre de l'adxl362 
* Parametres	: addr = adresse du registre 
*				: data = donnée a écrire
******************************************************************************/
void adxl362_write_register(uint8_t addr, uint8_t data);

/***************************************************************************//**
* Ecriture de 2 registres succesif de l'adxl362 
* Parametres	: addr = adresse du registre de poids faible 
*				: data = donnée a écrire
******************************************************************************/
void adxl362_write_two_register(uint8_t addr, uint16_t data);

/***************************************************************************//**
* Lecture des données X,Y et Z sur 8bits avec la fonction adxl362_read_register
******************************************************************************/
int8_t adxl362_readXData8bits(void);
int8_t adxl362_readYData8bits(void);
int8_t adxl362_readZData8bits(void);

/***************************************************************************//**
* Lecture des données X,Y,Z et Temperature (Temp) 
* sur 12bits avec la fonction adxl362_read_two_register
******************************************************************************/
int16_t adxl362_readXData12bits(void);
int16_t adxl362_readYData12bits(void);
int16_t adxl362_readZData12bits(void);
int16_t adxl362_readTempData12bits(void);

/***************************************************************************//**
* Lecture du nombres d'échantillons présent dans la FIFO
******************************************************************************/
uint16_t adxl362_fifo_nb_sample(void);

/***************************************************************************//**
* Lecture des données X,Y et Z en une seul fonction 
* permet de gagner en rapidite car la communication est ouverte une seul fois
* Parametres	: XData, YData, ZData = adresses des variables
******************************************************************************/
void adxl362_readXYZData(int16_t *XData, int16_t *YData, int16_t *ZData);

/***************************************************************************//**
* Reset de l'adxl362
******************************************************************************/
void adxl362_reset(void);

/***************************************************************************//**
* Lecture du registre STATUS de l'adxl362 permet de connaitre l'etat 
* dans le quel ce trouve l'adxl362.
* Premet également de clear des interruptions
******************************************************************************/	
uint8_t adxl362_status(void);

/***************************************************************************//**
* Ecriture des parametres de detections dans les registres.
* Parametres choisi au préalable en modifiant detection 
* Parametre	: detection = variable des parametres souhaité pour la detection
******************************************************************************/
void adxl362_detection_config(adxl362_detection_TypeDef *detection);

/***************************************************************************//**
* Ecriture des parametres de la FIFO dans les registres.
* Parametres choisi au préalable en modifiant fifo 
* Parametre	: fifo = variable des parametres souhaité pour la FIFO
******************************************************************************/
void adxl362_fifo_config(adxl362_fifo_TypeDef *fifo);

/***************************************************************************//**
* Ecriture des parametres des interruptions dans les registres.
* Parametres choisi au préalable en modifiant interruption 
* Parametres	: interruption = variable des parametres souhaité pour l'interruption
*				: numInt = choix de l'interruption (1 ou 2)
******************************************************************************/
void adxl362_interruption_config(adxl362_interruption_TypeDef *interruption, int numInt);

/***************************************************************************//**
* Ecriture des parametres de filter dans les registres.
* Parametres choisi au préalable en modifiant filtre 
* Parametre	: filtre = variable des parametres souhaité pour filter
******************************************************************************/
void adxl362_filtre_config(adxl362_filtre_TypeDef *filtre);

/***************************************************************************//**
* Ecriture des parametres de power dans les registres.
* Parametres choisi au préalable en modifiant power 
* Parametre	: power = variable des parametres souhaité pour power
******************************************************************************/
void adxl362_power_config(adxl362_power_TypeDef *power);

/***************************************************************************//**
* Initialisation de l'adxl362 en modifiant les differentes variables 
* qui vont servir ensuite au fonctions de configuration
* Attention ne pas modifier l'ordre de configuration des registres
******************************************************************************/
void adxl362_init(void);

/*********************************************************************
* Fonction d'analyse de mouvement qui va utiliser pour verifier
* si le mouvement est un mouvement continu (susceptible  d'être un vol)
* ou non. Les seuils seront a ajuster par la suite lors des phases de test
* Parametres	: port = port du pin de reveil du mode EM4
*				: pin = pin de reveil du mode EM4
*********************************************************************/
uint8_t adxl362_analyseMouvement(GPIO_Port_TypeDef port, unsigned int pin);

/*********************************************************************
* Fonction qui attend la fin de l'interruption 
* Attention la fonction est faite pour une interruption 
* active a l'état haut
* Parametres	: port = port du pin de reveil du mode EM4
*				: pin = pin de reveil du mode EM4
*********************************************************************/
void adxl362_stopInterruption(GPIO_Port_TypeDef port, unsigned int pin);

/***************************************************************************//**
* Lecture des registers de 0 a 3 afin de verifier que la lecture fonctions 
* a utiliser uniquement pour debuger
******************************************************************************/
void adxl362_checkAllID(void);

/***************************************************************************//**
* Lecture des registers de 20 à 2E afin de verifier que la configuration
* des registres a fonctionné. A utiliser uniquement pour debuger
******************************************************************************/
void adxl362_checkAllControlRegs(void);

/***************************************************************************//**
* ATTENTION FONCTION NON FINI NE PAS UTILISER EN L'ETAT
* Lecture des données dans la FIFO
* Lit le nombres d'échantillons entrer en parametres nb_samples
* Mets les echantillons dans le tableau tabFifo 
* Parametres	: nb_samples = nombre d'échantillons a lire
*				: tabFifo = adresse du tableau ou mettre les echantillons
******************************************************************************/
void adxl362_readFIFO(uint16_t nb_samples, uint16_t *tabFifo);

/***************************************************************************//**
* ATTENTION FONCTION NON FINI NE PAS UTILISER EN L'ETAT
* Fonction qui réalise l'autotest de l'adxl362
* Parametre	: mode = (true) demarre l'autotest ou (false) le stop
******************************************************************************/
void adxl362_self_test(bool mode);


#endif // PT_ADXL362_H

