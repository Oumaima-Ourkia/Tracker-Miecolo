/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

// -----------------------------------------------------------------------------
//                                   Includes
// -----------------------------------------------------------------------------
#include "em_gpio.h"
#include "adxl362.h"
#include "em_cmu.h"
// -----------------------------------------------------------------------------
//                              Macros and Typedefs
// -----------------------------------------------------------------------------






// -----------------------------------------------------------------------------
//                          Public Function Definitions
// -----------------------------------------------------------------------------

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void)
{
  // initialisation du GPIO et de la clock de BURAM
  initGPIO();
  CMU_ClockEnable(cmuClock_BURAM, true);
  GPIO_PinOutClear(US0CS_PORT, US0CS_PIN);

}

/***************************************************************************//**
 * App ticking function.
 ******************************************************************************/
void app_process_action(void)
{
  int16_t XDataM, YDataM, ZDataM;
  int16_t XDataP, YDataP, ZDataP;
  ////////////////////////////////////////////////////////////////////
  // les variables limite sont les seuils que seront a ajuster par la suite
  // attention limiteTemps 1 = 160ms sauf si modification des delay (a la fin de la boucle while)
  ////////////////////////////////////////////////////////////////////
  uint8_t limiteTemps = 50;
  uint8_t limiteMvt = 50;
  uint8_t limiteAcc = 30; // valeur mini constater 30mg

  // variables qui vont s'incrémenter et qui seront comparer au seuil fixer par les limites
  uint8_t temps = 0;
  uint8_t mvt = 0;

  // variable qui sera retourne. Si aucun vol detecter = 0
  uint8_t resultat = 0;

  // Initialisation des mesures précedentes

  adxl362_readXYZData(&XDataP, &YDataP, &ZDataP);


}


// initialisation des pins de l'adxl362 et du reveil de EM4
void initGPIO(void)
{
  // Enable clock (not needed on xG21)
  CMU_ClockEnable(cmuClock_GPIO, true);

  adxl362_spi_init();
}
void delay(uint16_t ms)
{
  for(uint16_t i = 0; i < ms; i++){
    sl_udelay_wait(100000); // = 100ms
  }
}
