/*
 * sl_adxl362_config.h
 *
 *  Created on: 7 avr. 2023
 *      Author: lynda
 */

#ifndef SL_ADXL362_CONFIG_H_
#define SL_ADXL362_CONFIG_H_

// -----------------------------------------------------------------------------
//                                   Includes
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//                              Macros and Typedefs
// -----------------------------------------------------------------------------

#define SL_ADXL362_SPI_PERIPHERAL               USART1
#define SL_ADXL362_SPI_PERIPHERAL_NO            0

// USART0 TX on PC00
#define SL_ADXL362_SPI_MOSI_PORT                  gpioPortA
#define SL_ADXL362_SPI_MOSI_PIN                   7

// USART0 RX on PC01
#define SL_ADXL362_SPI_MISO_PORT                  gpioPortA
#define SL_ADXL362_SPI_MISO_PIN                   6

// USART0 CLK on PC02
#define SL_ADXL362_SPI_CLK_PORT                 gpioPortA
#define SL_ADXL362_SPI_CLK_PIN                  8

// [USART_SL_ADXL362_SPI]$

// <gpio> SL_ADXL362_SPI_CS
// $[GPIO_SL_ADXL362_SPI_CS]
#define SL_ADXL362_SPI_CS_PORT                  gpioPortA
#define SL_ADXL362_SPI_CS_PIN                   4

// [GPIO_SL_ADXL362_SPI_CS]$

// <gpio optional=true> SL_ADXL362_INT
// $[GPIO_SL_ADXL362_INT]
#define SL_ADXL362_INT_PORT                     gpioPortA
#define SL_ADXL362_INT_PIN                      5





// -----------------------------------------------------------------------------
//                          Public Function Definitions
// -----------------------------------------------------------------------------



#endif /* SL_ADXL362_CONFIG_H_ */
