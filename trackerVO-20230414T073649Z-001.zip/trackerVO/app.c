/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include "em_gpio.h"
#include "em_usart.h"
#include "em_eusart.h"
#include "em_gpio.h"
#include "stdio.h"
#include "string.h"
#include "em_chip.h"
#include "em_cmu.h"  //bibliotheque qui permet d'utiliser CMU_ClockEnable(cmuClock_GPIO, true);
#include "sl_adxl362.h"
#include "Drivers/USART.h"
//#include "Middlewares/adxl362.h"
#include "sl_device_init_emu_config.h" //bibliotheque qui permet d'utiliser la fonction  EMU_UnlatchPinRetention()
#include "sl_status.h"
#include "sl_imu_adxl362.h"

#define INT_PB1_PORT  gpioPortB
#define INT_PB1_PIN   1
#define USART_DB USART1
  int16_t ovecm[3];
  int16_t avecm[3];
  sl_status_t status;

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/


void app_init(void)
{
  float accel;
  uint16_t X,Y,Z;
  //GPIO_PinModeSet(gpioPortC, 6, gpioModePushPull, 1); // reg enable
 status= sl_ADXL362_spi_init();
  //GPIO_PinModeSet(gpioPortA, 7, gpioModePushPull, 1);

 //sl_imu_get_acceleration_raw_data(avecm);
// status= adxl362_status();
 status= readXYZData(X, Y, Z);
//sl_sensor_imu_init();
//status=sl_sensor_imu_enable(true);
//status=sl_sensor_imu_get(ovecm,avecm);
//status= status;




}

/***************************************************************************//**
 * App ticking function.
 ******************************************************************************/
void app_process_action(void)
{

// volatile sl_status_t sl_imu_get_acceleration_raw_data(avecm);

}
