/*
 *
 * @file sl_imu_ADXL362.c
 * @brief Inertial Measurement Unit driver
 * @author Lynda MAACHA
 * @version 1.0
 * @date 07/04/2023
 */

// -----------------------------------------------------------------------------
//                                   Includes
// -----------------------------------------------------------------------------

#include "sl_imu_adxl362.h"
#include "sl_adxl362.h"
#include "sl_imu.h"
#include "sl_sleeptimer.h"

// -----------------------------------------------------------------------------
//                              Macros and Typedefs
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//                          Static Function Declarations
// -----------------------------------------------------------------------------
/** @cond DO_NOT_INCLUDE_WITH_DOXYGEN */
static uint8_t IMU_state = IMU_STATE_DISABLED; /**< IMU state variable                                  */
static float gyroSampleRate;                   /**< Gyroscope sample rate                               */
static float accelSampleRate;                  /**< Accelerometer sample rate                           */
static volatile bool dataReady;                /**< Flag to show if new accel/gyro data ready to read   */
static uint32_t IMU_isDataReadyQueryCount = 0; /**< The number of the total data ready queries          */
static uint32_t IMU_isDataReadyTrueCount = 0;  /**< The number of queries when data is ready            */
static sl_imu_sensor_fusion_t fuseObj;         /**< Structure to store the sensor fusion data           */
/** @endcond */

// -----------------------------------------------------------------------------
//                                Global Variables
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//                                Static Variables
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//                          Public Function Definitions
// -----------------------------------------------------------------------------

void sl_imu_get_acceleration_raw_data(float avec[3])
{
  IMU_state = IMU_STATE_DISABLED;
  if ( IMU_state == IMU_STATE_READY ) {
    avec[0] = 0;
    avec[1] = 0;
    avec[2] = 0;

    return;
  }
  sl_ADXL362_accel_read_data(avec);
}


/***************************************************************************//**
 *    Retrieves the processed acceleration data
 ******************************************************************************/
void sl_imu_get_acceleration(int16_t avec[3])
{
  if ( fuseObj.aAccumulatorCount > 0 ) {
    avec[0] = (int16_t) (1000.0f * fuseObj.aAccumulator[0] / fuseObj.aAccumulatorCount);
    avec[1] = (int16_t) (1000.0f * fuseObj.aAccumulator[1] / fuseObj.aAccumulatorCount);
    avec[2] = (int16_t) (1000.0f * fuseObj.aAccumulator[2] / fuseObj.aAccumulatorCount);
    fuseObj.aAccumulator[0] = 0;
    fuseObj.aAccumulator[1] = 0;
    fuseObj.aAccumulator[2] = 0;
    fuseObj.aAccumulatorCount = 0;
  } else {
    avec[0] = 0;
    avec[1] = 0;
    avec[2] = 0;
  }
}

/***************************************************************************//**
 *    Retrieves the processed orientation data
 ******************************************************************************/
void sl_imu_get_orientation(int16_t ovec[3])
{
  ovec[0] = (int16_t) (100.0f * IMU_RAD_TO_DEG_FACTOR * fuseObj.orientation[0]);
  ovec[1] = (int16_t) (100.0f * IMU_RAD_TO_DEG_FACTOR * fuseObj.orientation[1]);
  ovec[2] = (int16_t) (100.0f * IMU_RAD_TO_DEG_FACTOR * fuseObj.orientation[2]);
}

/***************************************************************************//**
 *    Gets a new set of data from the accel and gyro sensor and updates the
 *    fusion calculation
 ******************************************************************************/
void sl_imu_update(void)
{
  sl_imu_fuse_update(&fuseObj);
}

/***************************************************************************//**
 *    Resets the fusion calculation
 ******************************************************************************/
void sl_imu_reset(void)
{
  sl_imu_fuse_reset(&fuseObj);
}

/***************************************************************************//**
 *    Checks if there is new accel/gyro data available for read
 ******************************************************************************/
bool sl_imu_is_data_ready(void)
{
  bool ready=true;

  if ( IMU_state != IMU_STATE_READY ) {
    return false;
  }

  //ready = sl_adxl362_is_data_ready();
  IMU_isDataReadyQueryCount++;

  if ( ready ) {
    IMU_isDataReadyTrueCount++;
  }

  return ready;
}
