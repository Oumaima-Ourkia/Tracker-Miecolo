/*
 *
 * @file sl_ADXL362.c
 * @brief Driver for the ADXL362 6-axis motion sensor
 * @author Lynda MAACHA
 * @version 1.0
 * @date 07/04/2023
 */

// -----------------------------------------------------------------------------
//                                   Includes
// -----------------------------------------------------------------------------
#include <stdint.h>
#include <stdio.h>
#include "em_usart.h"
#include "em_gpio.h"
#include "em_cmu.h"
#include "sl_sleeptimer.h"
#include "sl_adxl362.h"
#include "sl_adxl362_config.h"
// -----------------------------------------------------------------------------
//                              Macros and Typedefs
// -----------------------------------------------------------------------------
/* Concatenate preprocessor tokens A and B. */
#define SL_CONCAT(A, B) A ## B

/* Generate the cmu clock symbol based on instance. */
#define ADXL362_SPI_CLK(N) SL_CONCAT(cmuClock_USART, N)
// -----------------------------------------------------------------------------
//                          Static Function Declarations
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
//                                Global Variables
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//                                Static Variables
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//                          Public Function Definitions
// -----------------------------------------------------------------------------

/***************************************************************************//**
 *    Initializes the SPI bus in order to communicate with the ADXL362
 ******************************************************************************/
sl_status_t sl_ADXL362_spi_init(void)
{
  USART_TypeDef *usart = SL_ADXL362_SPI_PERIPHERAL;

  USART_InitSync_TypeDef init = USART_INITSYNC_DEFAULT;
  init.msbf = true;           // Send most significant byte first
  init.baudrate = 3300000;    // SPI-frequency at 3.3 MHz

  /* Enabling clock to USART */

  // Enable clock (not needed on xG21)
  CMU_ClockEnable(cmuClock_USART0, true);

  //CMU_ClockEnable(ADXL362_SPI_CLK(SL_ADXL362_SPI_PERIPHERAL_NO), true);
  //CMU_ClockEnable(cmuClock_GPIO, true);

  /* IO configuration */
  // Configure TX pin as an output
  GPIO_PinModeSet(SL_ADXL362_SPI_MOSI_PORT, SL_ADXL362_SPI_MOSI_PIN, gpioModePushPull, 0);
  // Configure RX pin as an input
   GPIO_PinModeSet(SL_ADXL362_SPI_MISO_PORT, SL_ADXL362_SPI_MISO_PIN, gpioModeInput, 0);
  // Configure CLK pin as an output low (CPOL = 0)


  GPIO_PinModeSet(SL_ADXL362_SPI_CLK_PORT, SL_ADXL362_SPI_CLK_PIN, gpioModePushPull, 0);
  // Configure CS pin as an output and drive inactive high
  GPIO_PinModeSet(SL_ADXL362_SPI_CS_PORT, SL_ADXL362_SPI_CS_PIN, gpioModePushPull, 1);

//  USART_Reset(SL_ADXL362_SPI_PERIPHERAL);

  /* Initialize USART, in SPI master mode. */
  //USART_InitSync(&usart, &init);

  /* Enable pins at correct UART/USART location. */
  GPIO->USARTROUTE[0].RXROUTE = (SL_ADXL362_SPI_MISO_PORT << _GPIO_USART_RXROUTE_PORT_SHIFT)
  | (SL_ADXL362_SPI_MISO_PIN << _GPIO_USART_RXROUTE_PIN_SHIFT);
  GPIO->USARTROUTE[0].TXROUTE = (SL_ADXL362_SPI_MOSI_PORT << _GPIO_USART_TXROUTE_PORT_SHIFT)
  | (SL_ADXL362_SPI_MOSI_PIN << _GPIO_USART_TXROUTE_PIN_SHIFT);
  GPIO->USARTROUTE[0].CLKROUTE = (SL_ADXL362_SPI_CLK_PORT << _GPIO_USART_CLKROUTE_PORT_SHIFT)
  | (SL_ADXL362_SPI_CLK_PIN << _GPIO_USART_CLKROUTE_PIN_SHIFT);

  return SL_STATUS_OK;
}

sl_status_t sl_ADXL362_accel_read_data(float *accel){

  uint8_t rawData[6];
  float accelRes;
  int16_t temp;

  /* Read the six raw data registers into data array */
  sl_ADXL362_read_register(ADXL362_XDATA_H, 6, &rawData[0]);

/* Convert the MSB and LSB into a signed 16-bit value and multiply by the resolution to get the G value */
  temp = ( (int16_t) rawData[0] << 8) | rawData[1];
  accel[0] = (float) temp * accelRes;
  temp = ( (int16_t) rawData[2] << 8) | rawData[3];
  accel[1] = (float) temp * accelRes;
  temp = ( (int16_t) rawData[4] << 8) | rawData[5];
  accel[2] = (float) temp * accelRes;

  return SL_STATUS_OK;
}



/***************************************************************************//**
 *    Reads register from the ICM20648 device
 ******************************************************************************/
void sl_ADXL362_read_register(uint16_t addr, int numBytes, uint8_t *data)
{
  uint8_t regAddr;
  uint8_t bank;

  regAddr = (uint8_t) (addr & 0x7F);
  bank = (uint8_t) (addr >> 7);

 // sl_icm20648_select_register_bank(bank);

  /* Enable chip select */
  //sl_icm20648_chip_select_set(true);

  /* Set R/W bit to 1 - read */
  USART_Tx(SL_ADXL362_SPI_PERIPHERAL, (regAddr | 0x80) );
  USART_Rx(SL_ADXL362_SPI_PERIPHERAL);
  /* Transmit 0's to provide clock and read the data */
  while ( numBytes-- ) {
    USART_Tx(SL_ADXL362_SPI_PERIPHERAL, 0x00);
    *data++ = USART_Rx(SL_ADXL362_SPI_PERIPHERAL);
  }
}
uint8_t adxl362_read_register(uint8_t addr)
{



  uint8_t RegValue = 0;

  GPIO_PinOutClear(SL_ADXL362_SPI_CS_PORT, SL_ADXL362_SPI_CS_PIN);

  USART_SpiTransfer(USART1, 0x0B);
  USART_SpiTransfer(USART1, addr);
  RegValue = USART_SpiTransfer(USART1, 0x00);

  //GPIO_PinOutSet(SL_ADXL362_SPI_CS_PORT, SL_ADXL362_SPI_CS_PIN);
  //sl_sleeptimer_delay_millisecond(5);

  return RegValue;
}

uint8_t adxl362_status(void)
{
  uint8_t status = adxl362_read_register(ADXL362_STATUS);
  return status;
}
void readXYZData(int16_t *XData, int16_t *YData, int16_t *ZData)
{
//  GPIO_PinOutClear(SL_ADXL362_SPI_CS_PORT, SL_ADXL362_SPI_CS_PIN);

  USART_SpiTransfer(USART1, 0x0B);
  USART_SpiTransfer(USART1,ADXL362_XDATA_L);

  *XData = USART_SpiTransfer(USART1, 0x00);
  *XData = *XData + (USART_SpiTransfer(USART1, 0x00) << 8);
  sl_sleeptimer_delay_millisecond(5);

  *YData = USART_SpiTransfer(USART1, 0x00);
  *YData = *YData + (USART_SpiTransfer(USART1, 0x00) << 8);
  sl_sleeptimer_delay_millisecond(5);

  *ZData = USART_SpiTransfer(USART1, 0x00);
  *ZData = *ZData + (USART_SpiTransfer(USART1, 0x00) << 8);
  sl_sleeptimer_delay_millisecond(5);

  GPIO_PinOutSet(SL_ADXL362_SPI_CS_PORT, SL_ADXL362_SPI_CS_PIN);
  sl_sleeptimer_delay_millisecond(5);
}
