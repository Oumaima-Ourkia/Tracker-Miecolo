/*
 * USART.h
 *
 *  Created on: 10 déc. 2022
 *      Author: Mickael ROULLIER
 */

#ifndef DRIVERS_USART_H_
#define DRIVERS_USART_H_



void USART_Printf(char *chaine);
#endif /* DRIVERS_USART_H_ */
