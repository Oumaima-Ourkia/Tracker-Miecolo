#ifndef SL_BOARD_CONTROL_CONFIG_H
#define SL_BOARD_CONTROL_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

// <<< end of configuration section >>>

// <<< sl:start pin_tool >>>

// <<< sl:end pin_tool >>>

#endif // SL_BOARD_CONTROL_CONFIG
